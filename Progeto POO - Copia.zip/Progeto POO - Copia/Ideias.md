# UVV-Steam-POOII


Space battle shooter WPF MOO ICT - 16
===

#### Bugs

#### Novidades
* trocar a sua espaçonave/frota para qualquer uma do jogo. Alterando a arma da nave e os disparos
* naves da sua própria frota podem aparecer agora
* Atirar em naves da sua propria frota te faz perder pontos
* Naves atingidas emitem uma explosão ao serem destruidas
* Sistema de combo: número que conta quantas naves são abatidas em sequencia (pode aparcer na explosão da nave a partir da 2º nave em sequencia)
* 

#### Menu
1. Foto tela fundo espacial estrelado com:
   * A nave padrão no centro da tela com uma setinha para cada lado para selecionar a sua frota
   * Botão de iniciar

<br><br>

Car Racing Game WPF MOO ICT - 17
===

#### Bugs

#### Novidades
* Poderes: Ficam por 5 segundos após coletar o item
*   turbo: aumenta a velocidade
*   escudo: fica imune a qualquer dano contra outro carro
*   Diminui a velocidade do carro


#### Menu
1. Foto tela inicial com:
   * Botão de jogar
   * Foto do jogo
2. Escolha do carro
   * Carro que  vira mais rapido
   * Carro que anda mais lento
   * Moto acelera mais rapido e freia mais rapido

<br><br>

Sinple Pong game - 22
===

#### Bugs
* Bola tem nascimento estranho quando alguém pontua
* A velocidade da bola aumenta muito com a pontuação (Podemos fazer ela ficar mais rápida com o tempo e não com a pontuação)

#### Novidades
* Poderes: Ao rebater a bola encima de um item, a bola vai receber novas mecanicas até o próximo ponto e Ficam por 5 segundos após coletar o item.
* Bola grudenta: Permite que a bola grude na raquete e pode ser solta a qualquer momento.
* Bola rápida: Aumenta a velocidade da bola.
* Novo campo: Cria objetos no campo que mudam a tragetória da bola.
* Bolas multiplas: Aumenta a quantidade de bolas no campo, o jogo vai contar ponto pra cada uma, e vai parar pra proxima rodada somente quando a ultima for pontuada.
* Velocidade: Permite fazer com que a raquete do jogador que acertou se mova mais rapido
* 2 Players: Player1 vs CPU / Player1 vs Player2 

#### Menu
1. Foto tela inicial com:
   * Botão de jogar
   * Foto do jogo
2. Modo de jogo
   * Contra bot
   * Contra segundo jogador 
